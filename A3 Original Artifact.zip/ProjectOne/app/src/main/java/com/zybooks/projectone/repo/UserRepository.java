package com.zybooks.projectone.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.service.autofill.UserData;
import android.text.TextWatcher;

import com.zybooks.projectone.model.User;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    private static UserRepository userRepo;
    private final List<User> userList;
    private UserDatabase dbHelper;

    public static synchronized UserRepository getInstance(Context context) {
        if (userRepo == null) {
            userRepo = new UserRepository(context);
        }
        return userRepo;
    }

    private UserRepository(Context context) {
        userList = new ArrayList<>();
        dbHelper = new UserDatabase(context);
    }

    public List<User> getUsers() {
        return new ArrayList<>(userList);
    }

    // Create Method
    public void addUser(User user) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_EMAIL, user.getEmail());
        values.put(UserDatabase.UserTable.COL_NAME, user.getName());
        values.put(UserDatabase.UserTable.COL_PASSWORD, user.getPassword());

        db.insert(UserDatabase.UserTable.TABLE, null, values);
        db.close();

    }

    // Read Method
    public User getUser(String email) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        User user = null;
        Cursor cursor = null;

        try {
            String sql = "SELECT * FROM " + UserDatabase.UserTable.TABLE +
                    " WHERE " + UserDatabase.UserTable.COL_EMAIL + " = ? COLLATE NOCASE";
            cursor = db.rawQuery(sql, new String[]{email});

            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(UserDatabase.UserTable.COL_NAME));
                String password = cursor.getString(cursor.getColumnIndexOrThrow(UserDatabase.UserTable.COL_PASSWORD));
                user = new User(email, name, password);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close(); // Close the database connection after use
        }

        return user;
    }

    // Update Method
    public void updateUser(String email, String name, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_EMAIL, email);
        values.put(UserDatabase.UserTable.COL_NAME, name);
        values.put(UserDatabase.UserTable.COL_PASSWORD, password);

        db.update(UserDatabase.UserTable.TABLE, values, "email=?",
                new String[]{String.valueOf(email)});
    }

    // Delete Method
    public void deleteUser(String email) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(UserDatabase.UserTable.TABLE, "email=?",
                new String[]{String.valueOf(email)});
    }
}
