package com.zybooks.projectone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.projectone.model.User;
import com.zybooks.projectone.repo.UserRepository;
import com.zybooks.projectone.viewmodel.UserListViewModel;

import java.util.List;

public class LoginActivity extends AppCompatActivity {
    private EditText mUserName;
    private EditText mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        mUserName = findViewById(R.id.userName);
        mPassword = findViewById(R.id.password);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //UserRepository.getInstance(this).deleteStarterData();
        //UserRepository.getInstance(this).addStarterData();
    }

    public void onCreateAccountClick(View view) {
        Intent intent = new Intent(this, NewUser.class);
        startActivity(intent);
    }

    public void onLogin(View view) {
        String email = mUserName.getText().toString();
        String password = mPassword.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = UserRepository.getInstance(this).getUser(email);
        if (user != null) {
            if (user.getPassword().equals(password)) {
                Intent intent = new Intent(this, InventoryActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(this, "Wrong Password Entered!", Toast.LENGTH_LONG).show();
            }
        }
        else {
            Toast.makeText(this, "Email Not On File!", Toast.LENGTH_LONG).show();
            return;
        }
    }
}