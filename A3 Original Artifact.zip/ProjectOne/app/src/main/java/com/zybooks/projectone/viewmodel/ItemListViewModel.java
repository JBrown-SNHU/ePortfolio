package com.zybooks.projectone.viewmodel;

import android.app.Application;
import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.repo.InventoryRepository;
import java.util.List;

public class ItemListViewModel {

    private InventoryRepository itemRepo;

    public ItemListViewModel(Application application) {
        itemRepo = InventoryRepository.getInstance(application.getApplicationContext());
    }

    public List<Item> getItems() {
        return itemRepo.getItems();
    }

    public void addItem(Item item) {
        itemRepo.addItem(item);
    }

}