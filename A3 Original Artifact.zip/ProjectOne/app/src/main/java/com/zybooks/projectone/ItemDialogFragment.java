package com.zybooks.projectone;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class ItemDialogFragment extends DialogFragment {

    public interface OnItemEnteredListener {
        void onItemEntered(String itemText, int itemCount);
    }

    private OnItemEnteredListener mListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Context context = requireActivity();

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        // Get item name
        final EditText itemEditText = new EditText(context);
        itemEditText.setHint("Item Name");
        itemEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        layout.addView(itemEditText, new LinearLayout.LayoutParams
                (ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Get item count
        final EditText countEditText = new EditText(context);
        countEditText.setHint("Item Count");
        countEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
        layout.addView(countEditText, new LinearLayout.LayoutParams
                (ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));


        return new AlertDialog.Builder(requireActivity())
                .setTitle(R.string.enter_item)
                .setView(layout)
                .setPositiveButton(R.string.create, (dialog, whichButton) -> {
                    // Notify listener
                    String itemText = itemEditText.getText().toString().trim();
                    String countText = countEditText.getText().toString().trim();
                    int itemCount = countText.isEmpty() ? 0 : Integer.parseInt(countText);
                    mListener.onItemEntered(itemText, itemCount);
                })
                .setNegativeButton(R.string.cancel, null)
                .create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (OnItemEnteredListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}