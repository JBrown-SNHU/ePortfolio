package com.zybooks.projectone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.repo.InventoryDatabase;
import com.zybooks.projectone.repo.InventoryRepository;

public class ItemDetailsActivity extends AppCompatActivity {

    TextView mItemName;
    TextView mItemCount;
    EditText mEditCount;
    private Item mItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_details);

        Intent intent = getIntent();
        mItem = (Item) intent.getSerializableExtra("item_key");

        if (mItem != null) {
            mItemName = findViewById(R.id.item_name);
            mItemCount = findViewById(R.id.stock_number);
            mEditCount = findViewById(R.id.edit_stock);

            mItemName.setText(mItem.getItemName());
            mItemCount.setText(String.valueOf(mItem.getCount()));
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void subtractStock(View view) {
        String strSubtractBy = mEditCount.getText().toString();

        if (strSubtractBy.isEmpty()) {
            Toast.makeText(this, "Please Enter A Number", Toast.LENGTH_SHORT).show();
            return;
        }
        int subtractBy = Integer.parseInt(strSubtractBy);
        int newNum = mItem.getCount() - subtractBy;
        if (newNum <= 0) {
            newNum = 0;
        }
        mItem.setCount(newNum);

        InventoryRepository.getInstance(this).updateItem(mItem.getItemName(), newNum);
        mItemCount.setText(String.valueOf(newNum));
    }

    public void addStock(View view) {
        String strAddBy = mEditCount.getText().toString();

        if (strAddBy.isEmpty()) {
            Toast.makeText(this, "Please Enter A Number", Toast.LENGTH_SHORT).show();
            return;
        }
        int addBy = Integer.parseInt(strAddBy);
        int newNum = mItem.getCount() + addBy;
        if (newNum >= 1000000) {
            newNum = 999999;
        }
        mItem.setCount(newNum);

        InventoryRepository.getInstance(this).updateItem(mItem.getItemName(), newNum);
        mItemCount.setText(String.valueOf(newNum));
    }

    public void deleteItem(View view) {
        InventoryRepository.getInstance(this).deleteItem(mItem.getItemName());
        Intent intent = new Intent(this, InventoryActivity.class);
        startActivity(intent);
    }
}
