package com.zybooks.projectone;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.telephony.SmsManager;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.repo.InventoryRepository;
import com.zybooks.projectone.viewmodel.ItemListViewModel;

import java.util.List;

public class InventoryActivity extends AppCompatActivity implements ItemDialogFragment.OnItemEnteredListener {

    private ItemAdapter mItemAdapter;
    private RecyclerView mRecyclerView;
    private ItemListViewModel mItemListViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        mItemListViewModel = new ItemListViewModel(getApplication());

        findViewById(R.id.add_item_button).setOnClickListener(view -> addItemClick());

        // Create grid layout
        mRecyclerView = findViewById(R.id.item_recycler_view);
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        // Show the items
        updateUI(mItemListViewModel.getItems());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the items when returning to this activity
        updateUI(mItemListViewModel.getItems());
        checkCountZero(mItemListViewModel);
    }

    private void updateUI(List<Item> itemList) {
        mItemAdapter = new ItemAdapter(itemList);
        mRecyclerView.setAdapter(mItemAdapter);
    }



    public void checkCountZero(ItemListViewModel list) {
        List<Item> itemList = list.getItems();
        Context context = mRecyclerView.getContext();

        for (int i = 0; i < itemList.size(); ++i) {
            if (itemList.get(i).getCount() == 0) {
                Item item = itemList.get(i);
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
                } else {
                    sendSMS(context,"9999999999", "Item " + item.getItemName() + " is out of stock!");
                }
            }
            if (itemList.get(i).getCount() <= 4) {
                Item item = itemList.get(i);
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
                } else {
                    sendSMS(context,"9999999999", "You are running low on " + item.getItemName() + "!");
                }
            }
        }
    }

    // Method to send SMS
    public void sendSMS(Context context, final String phoneNumber, final String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent to: " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed to Send", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public void onItemEntered(String itemText, int count) {
        if (itemText.length() > 0) {
            List<Item> myList = InventoryRepository.getInstance(this).getItems();
            for (int i = 0; i < myList.size(); ++i) {
                if (myList.get(i).getItemName().equalsIgnoreCase(itemText)) {
                    Toast.makeText(this,"Item Already Exists", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            Item item = new Item(itemText, count);
            InventoryRepository.getInstance(this).addItem(item);
            updateUI(mItemListViewModel.getItems());

            Toast.makeText(this, "Added " + item.getItemName(), Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "You Must Enter An Item Name ", Toast.LENGTH_SHORT).show();
        }
    }

    private void addItemClick() {
        ItemDialogFragment dialog = new ItemDialogFragment();
        dialog.show(getSupportFragmentManager(), "itemDialog");
    }

    private class ItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private Item mItem;
        private final TextView mItemTextView;
        private final TextView mItemCountTextView;
        private final ImageButton mEditButton;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mItemTextView = itemView.findViewById(R.id.item_text_view);
            mItemCountTextView = itemView.findViewById(R.id.item_count_view);
            mEditButton = itemView.findViewById(R.id.edit_button);

            // Click lister for edit button
            mEditButton.setOnClickListener(view-> {
                Context context = view.getContext();
                Intent intent = new Intent(context, ItemDetailsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("item_key",mItem);
                context.startActivity(intent);
            });
        }

        public void bind(Item item) {
            mItem = item;
            mItemTextView.setText(item.getItemName());
            mItemCountTextView.setText(String.valueOf(item.getCount()));
        }

        @Override
        public void onClick(View view) {
            Item item = mItem;
            Context context = view.getContext();
            Intent intent = new Intent(context, ItemDetailsActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("item_key", item);
            context.startActivity(intent);

        }


    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItemList;

        public ItemAdapter(List<Item> items) {
            mItemList = items;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
            holder.bind(mItemList.get(position));
        }

        @Override
        public int getItemCount() {
            return mItemList.size();
        }


    }
}