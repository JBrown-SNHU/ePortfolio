package com.zybooks.projectone.model;

import androidx.annotation.NonNull;

public class User {
    private String email;
    private String name;
    private String password;

    public User(@NonNull String userEmail,String userName, String userPassword) {
        email = userEmail;
        name = userName;
        password = userPassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
