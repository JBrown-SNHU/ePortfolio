package com.zybooks.projectone.viewmodel;

import android.app.Application;

import com.zybooks.projectone.model.User;
import com.zybooks.projectone.repo.UserRepository;
import java.util.List;


public class UserListViewModel {

    private UserRepository userRepo;

    public UserListViewModel(Application application) {
        userRepo = UserRepository.getInstance(application.getApplicationContext());
    }

    public List<User> getUsers() {

        return userRepo.getUsers();
    }

    public void addUser(User user) {
        userRepo.addUser(user);
    }

}

