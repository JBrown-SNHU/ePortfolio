package com.zybooks.projectone.model;

import androidx.annotation.NonNull;
import java.io.Serializable;

public class Item implements Serializable {
    private String itemName;
    private int itemCount;
    private long updateTime;

    public Item(@NonNull String itemName, int itemCount) {
        this.itemName = itemName;
        this.itemCount = itemCount;
        updateTime = System.currentTimeMillis();
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getCount() {
        return itemCount;
    }

    public void setCount(int itemCount) {
        this.itemCount = itemCount;
    }
    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }
}
