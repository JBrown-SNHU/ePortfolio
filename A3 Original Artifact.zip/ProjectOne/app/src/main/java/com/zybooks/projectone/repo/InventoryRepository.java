package com.zybooks.projectone.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.zybooks.projectone.model.Item;
import java.util.ArrayList;
import java.util.List;


public class InventoryRepository {

    private static InventoryRepository itemRepo;
    private final List<Item> itemList;
    private InventoryDatabase dbHelper;

    public static synchronized InventoryRepository getInstance(Context context) {
        if (itemRepo == null) {
            itemRepo = new InventoryRepository(context);
        }
        return itemRepo;
    }

    private InventoryRepository(Context context) {
        itemList = new ArrayList<>();
        dbHelper = new InventoryDatabase(context);
    }

    // Create Method
    public void addItem(Item item) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.ItemTable.COL_NAME, item.getItemName());
        values.put(InventoryDatabase.ItemTable.COL_COUNT, item.getCount());

        try {
            long newRowId = db.insertOrThrow(InventoryDatabase.ItemTable.TABLE, null, values);
            if (newRowId == -1) {
                Log.e("InventoryRepository", "Failed to insert item: " + item.getItemName());
            } else {
                Log.d("InventoryRepository", "Item inserted successfully: " + item.getItemName());
            }
        } catch (Exception e) {
            Log.e("InventoryRepository", "Error inserting item: " + item.getItemName(), e);
        } finally {
            db.close();
        }
    }

    // Read Method
    public Item getItem(String itemName) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Item item = null;
        Cursor cursor = null;

        try {
            String sql = "SELECT * FROM " + InventoryDatabase.ItemTable.TABLE +
                    " WHERE " + InventoryDatabase.ItemTable.COL_NAME + " = ? ";
            cursor = db.rawQuery(sql, new String[]{String.valueOf(itemName)});

            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_NAME));
                int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_COUNT));
                item = new Item(name, count);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        return item;
    }

    // Read All Method
    public List<Item> getItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<Item> itemList = new ArrayList<>();
        Cursor cursor = null;

        try {
            String sql = "SELECT * FROM " + InventoryDatabase.ItemTable.TABLE;
            cursor = db.rawQuery(sql, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_NAME));
                    int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_COUNT));
                    Item item = new Item(name, count);
                    itemList.add(item);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        return itemList;
    }

    // Update Method
    public int updateItem(String name, int count) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.ItemTable.COL_NAME, name);
        values.put(InventoryDatabase.ItemTable.COL_COUNT, count);

        db.update(InventoryDatabase.ItemTable.TABLE, values, "name=?",
                new String[]{String.valueOf(name)});
        db.close();
        return count;
    }

    // Delete Method
    public void deleteItem(String name) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(InventoryDatabase.ItemTable.TABLE, "name=?",
                new String[]{String.valueOf(name)});
    }


}