package com.zybooks.projectone.model;

import java.io.Serializable;

import androidx.annotation.NonNull;

import java.security.SecureRandom;
import java.util.Base64;

public class User implements Serializable
{
    private String email;
    private String name;
    private String password;
    private String phone;
    private String salt;

    // Class Constructor with phoneNumber as argument
    public User(@NonNull String userEmail,String userName, String userPassword, String userSalt, String phoneNumber)
    {
        email = userEmail;
        name = userName;
        password = userPassword;
        phone = phoneNumber;
        salt = userSalt;
    }

    // Class Constructor without phoneNumber and salt
    public User(@NonNull String userEmail, String userName, String userPassword)
    {
        email = userEmail;
        name = userName;
        password = userPassword;
        phone = "";
        salt = "";
    }

    // Class Constructor without salt
    public User(@NonNull String userEmail, String userName, String userPassword, String userPhone)
    {
        email = userEmail;
        name = userName;
        password = userPassword;
        phone = userPhone;
        salt = "";
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getPhone()
    {
        return phone;
    }

    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getSalt()
    {
        return salt;
    }

    public void setSalt(String salt)
    {
        this.salt = salt;
    }

}
