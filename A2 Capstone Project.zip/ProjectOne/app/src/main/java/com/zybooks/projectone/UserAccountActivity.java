package com.zybooks.projectone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.model.PasswordHasher;
import com.zybooks.projectone.model.User;
import com.zybooks.projectone.repo.InventoryRepository;
import com.zybooks.projectone.repo.UserRepository;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;

public class UserAccountActivity extends AppCompatActivity implements UserDialogFragment.OnItemEnteredListener{

    TextView mUserName;
    TextView mUserPhone;
    TextView mUserEmail;
    private User user;
    TextView mConfirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_account);

        // Set TextView
        mUserName = findViewById(R.id.user_name);
        mUserPhone = findViewById(R.id.user_phone);
        mUserEmail = findViewById(R.id.user_email);
        mConfirm = findViewById(R.id.confirm_delete);
        ImageView profilePic = findViewById(R.id.profile_pic);
        profilePic.setImageResource(R.drawable.profile);
        Button deleteButton = findViewById(R.id.delete);
        Button noButton = findViewById(R.id.delete_no);
        Button yesButton = findViewById(R.id.delete_yes);

        // On click listener for Delete User button
        deleteButton.setOnClickListener(v -> {
            //Sets yes and no button to visible and delete to gone
            mConfirm.setVisibility(View.VISIBLE);
            noButton.setVisibility(View.VISIBLE);
            yesButton.setVisibility(View.VISIBLE);
            deleteButton.setVisibility(View.GONE);

        });

        // On click listener for no Button
        noButton.setOnClickListener(v -> {
            // Sets delete to visible and yes and no to gone
            mConfirm.setVisibility(View.GONE);
            noButton.setVisibility(View.GONE);
            yesButton.setVisibility(View.GONE);
            deleteButton.setVisibility(View.VISIBLE);
        });


        // Retrieves user data from previous screen
        Intent intent = getIntent();
        String email = intent.getStringExtra("userEmail");
        user = UserRepository.getInstance(this).getUser(email);
        if (user == null)
        {
            Toast.makeText(this, "User is Null!", Toast.LENGTH_LONG).show();
        }
        else
        {
            mUserName.setText(PasswordHasher.decrypt(user.getName(), user.getPassword()));
            mUserEmail.setText(user.getEmail());
            if (!user.getPhone().isEmpty())
            {
                mUserPhone.setText(PasswordHasher.decrypt(user.getPhone(), user.getPassword()));
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // On click listener for edit button
    public void onEdit(View view)
    {
        UserDialogFragment dialog = new UserDialogFragment();

        Bundle args = new Bundle();
        args.putString("name", mUserName.getText().toString());
        args.putString("phone", mUserPhone.getText().toString());
        args.putString("email", mUserEmail.getText().toString());
        args.putString("password", user.getPassword());
        args.putString("password2", user.getPassword());

        dialog.setArguments(args);
        dialog.show(getSupportFragmentManager(), "userDialog");
    }

    // Method to update the user's account data
    @Override
    public void onItemEntered(String name, String phone, String email, String password)
    {
        User changedUser;

        // Makes sure phone does not equal "None"
        if (phone.equals("None"))
        {
            phone = "";
        }

        // Step1: Check is the user email and password changed
        if (!user.getEmail().equals(email) && !user.getPassword().equals(password))
        {
            // Updates the creator on all of the user's items.
            InventoryRepository.getInstance(this).updateAll(user.getEmail(), user.getPassword(), email, "email");

            // Generates a new salt, hashes the password, and encrypts the items created by the user with new password
            changedUser = PasswordHasher.hashUser(new User(email, name, password, phone));
            assert changedUser != null;

            // Pull's the user's items using hte new email, and updates encrypts them with the new key
            List<Item> myList = InventoryRepository.getInstance(this).getItems(changedUser.getEmail(), user.getPassword());
            InventoryRepository.getInstance(this).updateCorrectionPassword(myList, changedUser.getEmail(), changedUser.getPassword());

            // Updates all changes to database
            UserRepository.getInstance(this).updateCorrection(user, changedUser,"email and password");

            // Push User to login page, and prompt to login using new credentials
            Toast.makeText(this, "Please login with new password", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

        // Step2: Check if user email changed and password stayed the same
        if (!user.getEmail().equals(email) && user.getPassword().equals(password))
        {
            changedUser = new User(email, name, user.getPassword(), user.getSalt(), phone);

            // Updates the creator on all of the user's items.
            InventoryRepository.getInstance(this).updateAll(user.getEmail(), user.getPassword(), email, "email");

            // Submit changes to the user to the database
            UserRepository.getInstance(this).updateCorrection(user, changedUser,"email");

            // Push User to login page, and prompt to login using new credentials
            Toast.makeText(this, "Please login with new email", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

        // Step 3: Check if the user changed their password and email stayed the same
        if (user.getEmail().equals(email) && !user.getPassword().equals(password))
        {
            // If user changed their password, generates a new salt, hashes the password, and updates the database
            changedUser = PasswordHasher.hashUser(new User(user.getEmail(), name, password, phone));
            assert changedUser != null;

            // Pulls all the user's items, and encrypts them with the new key
            List<Item> myList = InventoryRepository.getInstance(this).getItems(user.getEmail(), user.getPassword());
            InventoryRepository.getInstance(this).updateCorrectionPassword(myList, user.getEmail(), changedUser.getPassword());

            // Updates all changes to database
            UserRepository.getInstance(this).updateCorrection(user, changedUser,"password");

            // Push User to login page, and prompt to login using new credentials
            Toast.makeText(this, "Please login with new password", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }
        // Step 4: If neither the password or email changed. User remains on page
        if (user.getEmail().equals(email) && user.getPassword().equals(password))
        {
            // Updates the changes to the database
            UserRepository.getInstance(this).updateUser(user.getEmail(), name, user.getPassword(), phone, user.getSalt());

            // Make temporary changes for this screen, until user leaves the page
            mUserName.setText(name);
            if (!phone.isEmpty())
            {
                mUserPhone.setText(phone);
            }
            else
            {
                mUserPhone.setText("None");
            }
        }
    }

    // Method to Delete the user
    public void onDelete(View view)
    {
        // Wipes uer item and then deletes use account
        InventoryRepository.getInstance(this).deleteAll(user.getEmail());
        UserRepository.getInstance(this).deleteUser(user.getEmail());

        // Pushes the user to the login screen
        Toast.makeText(this, "Your items and account have been deleted", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}