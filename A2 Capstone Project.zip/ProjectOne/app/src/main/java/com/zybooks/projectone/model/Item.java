package com.zybooks.projectone.model;

import androidx.annotation.NonNull;
import java.io.Serializable;

public class Item implements Serializable
{
    private String itemName;
    private int itemCount;
    private String creator;
    private int itemId;

    public Item(@NonNull String itemName, int itemCount, String createdBy)
    {
        this.itemName = itemName;
        this.itemCount = itemCount;
        this.creator = createdBy;
        itemId = 0;
    }

    public Item(@NonNull String itemName, int itemCount, String createdBy, int itemId)
    {
        this.itemName = itemName;
        this.itemCount = itemCount;
        this.creator = createdBy;
        this.itemId = itemId;

    }

    public String getItemName()
    {
        return itemName;
    }

    public void setItemName(String itemName)
    {
        this.itemName = itemName;
    }

    public int getCount()
    {
        return itemCount;
    }

    public void setCount(int itemCount)
    {
        this.itemCount = itemCount;
    }

    public String getCreator()
    {
        return creator;
    }

    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    public int getItemId()
    {
        return itemId;
    }

    public void setItemId(int itemId)
    {
        this.itemId = itemId;
    }

}
