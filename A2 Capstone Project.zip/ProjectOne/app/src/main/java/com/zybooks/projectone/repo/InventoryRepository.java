package com.zybooks.projectone.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.model.PasswordHasher;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class InventoryRepository
{

    private static InventoryRepository itemRepo;
    private final List<Item> itemList;
    private InventoryDatabase dbHelper;

    public static synchronized InventoryRepository getInstance(Context context)
    {
        if (itemRepo == null) {
            itemRepo = new InventoryRepository(context);
        }
        return itemRepo;
    }

    private InventoryRepository(Context context)
    {
        itemList = new ArrayList<>();
        dbHelper = new InventoryDatabase(context);
    }

    // Create Method
    public void addItem(Item item, String key)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT MAX(itemId) FROM " + InventoryDatabase.ItemTable.TABLE +
                        " WHERE creator =?", new String[]{item.getCreator()});

        int newItemId = 1;
        if (cursor.moveToFirst())
        {
            newItemId = cursor.getInt(0) + 1;
        }
        cursor.close();

        // encrypt item
        item.setItemName(PasswordHasher.encrypt(item.getItemName(), key));

        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.ItemTable.COL_ITEM_ID, newItemId);
        values.put(InventoryDatabase.ItemTable.COL_CREATOR, item.getCreator());
        values.put(InventoryDatabase.ItemTable.COL_NAME, item.getItemName());
        values.put(InventoryDatabase.ItemTable.COL_COUNT, item.getCount());

        db.insertOrThrow(InventoryDatabase.ItemTable.TABLE, null, values);
        db.close();
    }

    // Read One Method
    public Item getItem(String createdBy, int itemId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;

        try {
            // Query the database
            cursor = db.rawQuery("SELECT * FROM " + InventoryDatabase.ItemTable.TABLE +
                            " WHERE " + InventoryDatabase.ItemTable.COL_CREATOR + " =? AND " +
                            InventoryDatabase.ItemTable.COL_ITEM_ID + " =?",
                    new String[]{createdBy, String.valueOf(itemId)});

            // Check if a result exists
            if (cursor != null && cursor.moveToFirst()) {
                // Safely retrieve values from the cursor
                String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_NAME));
                int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_COUNT));

                // Return the found item
                return new Item(name, count, createdBy, itemId);
            } else {
                Log.e("getItem", "Item not found for creator: " + createdBy + ", itemId: " + itemId);
                return null; // Item not found
            }
        } catch (Exception e) {
            Log.e("getItem", "Error retrieving item", e);
            return null; // Handle unexpected errors
        } finally {
            // Close cursor and database safely
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // Read All Method
    public List<Item> getItems(String createdBy, String key)
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<Item> itemList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryDatabase.ItemTable.TABLE +
                " WHERE creator =?", new String[]{createdBy});

        // Used to update itemId
        int itemNum = 0;

        while (cursor.moveToNext())
        {
            ++itemNum;
            int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_ITEM_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_NAME));
            int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_COUNT));

            // Decrypts before adding item to the list
            String orgName = PasswordHasher.computeHash(name);
            if (PasswordHasher.validateHash(name, orgName))
            {
                name = PasswordHasher.decrypt(name, key);
            }

            // If itemId is not the expected number, then changes itemId to itemNum
            if (itemNum != itemId)
            {
                // Updates the item in the database
                updateCorrectionID(createdBy, itemId,count, name, key, itemNum);
            }
            // Updates the item in the database

            // Adds item to the list
            Item item = new Item(name, count, createdBy, itemId);
            itemList.add(item);

        }
        cursor.close();
        db.close();
        return itemList;
    }

    // Update Method
    public void updateItem(String creator, int itemId, int count, String itemName, String key)
    {
        // encrypt item name on update
        String orgItem = PasswordHasher.computeHash(itemName);
        if (PasswordHasher.validateHash(itemName, orgItem))
        {
            itemName = PasswordHasher.encrypt(itemName, key);
        }


        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.ItemTable.COL_COUNT, count);
        values.put(InventoryDatabase.ItemTable.COL_NAME, itemName);

        db.update(InventoryDatabase.ItemTable.TABLE, values,
                InventoryDatabase.ItemTable.COL_CREATOR + "=? AND " +
                InventoryDatabase.ItemTable.COL_ITEM_ID + "=?",
                new String[]{creator, String.valueOf(itemId)});
        db.close();
    }

    // Update Method used to correct the itemId, only used in ReadAll Method
    public void updateCorrectionID(String creator, int itemId, int count, String itemName, String key, int correction)
    {
        // encrypt item name on update
        String orgItem = PasswordHasher.computeHash(itemName);
        if (PasswordHasher.validateHash(itemName, orgItem))
        {
            itemName = PasswordHasher.encrypt(itemName, key);
        }


        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.ItemTable.COL_COUNT, count);
        values.put(InventoryDatabase.ItemTable.COL_NAME, itemName);
        values.put(InventoryDatabase.ItemTable.COL_ITEM_ID, correction);

        db.update(InventoryDatabase.ItemTable.TABLE, values,
                InventoryDatabase.ItemTable.COL_CREATOR + "=? AND " +
                        InventoryDatabase.ItemTable.COL_ITEM_ID + "=?",
                new String[]{creator, String.valueOf(itemId)});
        db.close();
    }

    // Update Method used to change an email, used in combination with update all
    public void updateCorrectionEmail(String creator, int itemId, int count, String itemName, String key, String correction)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.ItemTable.COL_COUNT, count);
        values.put(InventoryDatabase.ItemTable.COL_NAME, itemName);
        values.put(InventoryDatabase.ItemTable.COL_CREATOR, correction);

        db.update(InventoryDatabase.ItemTable.TABLE, values,
                InventoryDatabase.ItemTable.COL_CREATOR + "=? AND " +
                        InventoryDatabase.ItemTable.COL_ITEM_ID + "=?",
                new String[]{creator, String.valueOf(itemId)});
        db.close();
    }

    // Update Method used to change an email, used in combination with update all
    public void updateCorrectionPassword(List<Item> list, String creator, String key)
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryDatabase.ItemTable.TABLE +
                " WHERE creator =?", new String[]{creator});

        while (cursor.moveToNext())
        {
            int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_ITEM_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_NAME));
            int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_COUNT));

           for (int i = 0; i < list.size(); ++i)
           {
               if (itemId == list.get(i).getItemId())
               {
                   updateItem(creator, itemId, count, list.get(i).getItemName(), key);
               }
           }
        }
        cursor.close();
        db.close();
    }

    // Update All, utilized updateCorrectionEmail or updateCorrectionPassword
    public void updateAll(String creator, String key, String correction, String whichUpdate)
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryDatabase.ItemTable.TABLE +
                " WHERE creator =?", new String[]{creator});

        while (cursor.moveToNext())
        {
            int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_ITEM_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_NAME));
            int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_COUNT));

            // Updates the item in the database
            if (whichUpdate.equals("email"))
            {
                updateCorrectionEmail(creator, itemId, count, name, key, correction);
            }
        }
        cursor.close();
        db.close();
    }

    // Delete Method
    public void deleteItem(String creator, int itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(InventoryDatabase.ItemTable.TABLE,
                InventoryDatabase.ItemTable.COL_CREATOR + "=? AND " +
                        InventoryDatabase.ItemTable.COL_ITEM_ID + "=?",
                new String[]{creator, String.valueOf(itemId)});
        db.close();
    }

    // Delete All Method
    public void deleteAll(String createdBy)
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryDatabase.ItemTable.TABLE +
                " WHERE creator =?", new String[]{createdBy});

        // Iterates through database selects items where creator equals createdBy
        while (cursor.moveToNext())
        {
            int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.ItemTable.COL_ITEM_ID));

            // Deletes item from database
            deleteItem(createdBy, itemId);
        }
        cursor.close();
        db.close();
    }


}