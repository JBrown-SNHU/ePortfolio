package com.zybooks.projectone.model;

import android.os.Message;
import android.provider.Settings;

import javax.crypto.SecretKeyFactory;
import javax.crypto.interfaces.PBEKey;
import javax.crypto.spec.PBEKeySpec;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

public class PasswordHasher
{
    private static final int SALT_LENGTH = 16;
    private static final int HASH_LENGTH = 256;
    private static final int ITERATIONS = 100000;

    // Hash the password
    public static String hashPassword(String password, byte[] salt)
        throws NoSuchAlgorithmException, InvalidKeySpecException
    {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, HASH_LENGTH);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] hash = factory.generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(hash);
    }

    // Generate random salt into string
    public static String generateSalt()
    {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    // Convert salt string to byte
    public static byte[] decodeSalt(String salt)
    {
        return Base64.getDecoder().decode(salt);
    }

    // Function to return a user with a hash password and a randomly generated salt
    public static User hashUser(User user)
    {
        try
        {
            // Generates salt and sets it to user.salt
            String salt = PasswordHasher.generateSalt();
            user.setSalt(salt);

            // Decodes salt to bytes and hashes the password, and sets the new hashed password
            byte[] saltBytes = PasswordHasher.decodeSalt(salt);
            String hashedPassword = PasswordHasher.hashPassword(user.getPassword(), saltBytes);
            user.setPassword(hashedPassword);

            return user;
        }
        catch (NoSuchAlgorithmException | InvalidKeySpecException e)
        {
            e.printStackTrace();
        }

        return null;
    }

    // Used to help determine if a data has already been encrypted
    public static String computeHash(String source)
    {
        try
        {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(source.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hashBytes);
        }
        catch (NoSuchAlgorithmException e)
        {
            throw new RuntimeException(e);
        }
    }

    // XOR Method to encrypt using a key
    public static String xorEncryptDecrypt(String source, String key)
    {
        int keyLength = key.length();
        int sourceLength = source.length();

        // Check for valid input
        if (source.isEmpty() || key.isEmpty())
        {
            throw new IllegalArgumentException("Key and source must not be empty");
        }

        StringBuilder output = new StringBuilder(sourceLength);
        for (int i = 0; i < sourceLength; ++i)
        {
            // XOR encrypt and append to output
            char encryptedChar = (char) (source.charAt(i) ^ key.charAt(i % keyLength));
            output.append(encryptedChar);
        }
        assert(output.length() == sourceLength);

        return output.toString();
    }

    // Encryrpt Method to avoid confusion
    public static String encrypt(String source, String key)
    {
        return xorEncryptDecrypt(source, key);
    }

    // Decrypt Method to avoid confusion
    public static String decrypt(String source, String key)
    {
        return xorEncryptDecrypt(source, key);
    }

    // Function using ComputeHash to test if data has already been encrypted
    public static boolean validateHash(String source, String originalHash)
    {
        return computeHash(source).equals(originalHash);
    }

    // Encrypt a user
    public static User encryptUser(User user)
    {
        user.setName(encrypt(user.getName(), user.getPassword()));
        if (!user.getPhone().isEmpty())
        {
            user.setPhone(encrypt(user.getPhone(), user.getPassword()));
        }
        return user;
    }

    // Decrypt a user
    public static User decryptUser(User user)
    {
        user.setName(decrypt(user.getName(), user.getPassword()));
        if (!user.getPhone().isEmpty())
        {
            user.setPhone(decrypt(user.getPhone(), user.getPassword()));
        }
        return user;
    }
}
