package com.zybooks.projectone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.model.PasswordHasher;
import com.zybooks.projectone.model.User;
import com.zybooks.projectone.repo.InventoryDatabase;
import com.zybooks.projectone.repo.InventoryRepository;

public class ItemDetailsActivity extends AppCompatActivity {

    TextView mItemName;
    TextView mItemCount;
    EditText mEditCount;
    TextView mItemId;
    private Item mItem;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_details);

        // Retrieves user data from previous screen
        user = (User) getIntent().getSerializableExtra("user");
        if (user == null)
        {
            Toast.makeText(this, "User is Null!", Toast.LENGTH_LONG).show();
        }

        // Retrieves item data from previous screen
        mItem =  (Item)getIntent().getSerializableExtra("item_key");
        if (mItem != null) {
            mItem.setItemName(PasswordHasher.decrypt(mItem.getItemName(), user.getPassword()));
            mItemName = findViewById(R.id.item_name);
            mItemCount = findViewById(R.id.stock_number);
            mEditCount = findViewById(R.id.edit_stock);
            mItemId = findViewById(R.id.item_id_view);
            mItemName.setText(mItem.getItemName());
            mItemCount.setText(String.valueOf(mItem.getCount()));
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Method to subtract an item's stock
    public void subtractStock(View view) {
        String strSubtractBy = mEditCount.getText().toString();

        // Check if user enter a number before pressing button
        if (strSubtractBy.isEmpty()) {
            Toast.makeText(this, "Please Enter A Number", Toast.LENGTH_SHORT).show();
            return;
        }
        // Converts string to integer and subtracts from count
        int subtractBy = Integer.parseInt(strSubtractBy);
        int newNum = mItem.getCount() - subtractBy;
        // If the new number is less than 0, then it will be set to 0
        if (newNum <= 0) {
            newNum = 0;
        }
        mItem.setCount(newNum);

        // Updates the database
        InventoryRepository.getInstance(this).updateItem(user.getEmail(), mItem.getItemId(),
                newNum, mItem.getItemName(), user.getPassword());
        mItemCount.setText(String.valueOf(newNum));

        // Test that item is encrypted on update
        Item item = InventoryRepository.getInstance(this).getItem(user.getEmail(), mItem.getItemId());

        // Goes back to inventory activity
        Intent intent = new Intent(this, InventoryActivity.class);
        // Passes user data back to inventory activity to prevent crashing that would occur
        intent.putExtra("userEmail", user.getEmail());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    // Method to add an item's stock
    public void addStock(View view) {
        String strAddBy = mEditCount.getText().toString();

        // Check if a user entered a number before pressing the button
        if (strAddBy.isEmpty()) {
            Toast.makeText(this, "Please Enter A Number", Toast.LENGTH_SHORT).show();
            return;
        }
        // Converts the string to an integer and adds the number to the item's count
        int addBy = Integer.parseInt(strAddBy);
        int newNum = mItem.getCount() + addBy;
        // Checks if the number is greater than or equal to 1 million, if so, it set the new number
        // equal to 1 less than a million to prevent overflows.
        if (newNum >= 1000000) {
            newNum = 999999;
        }
        mItem.setCount(newNum);

        // Updates the database
        InventoryRepository.getInstance(this).updateItem(user.getEmail(), mItem.getItemId(),
                newNum, mItem.getItemName(), user.getPassword());
        mItemCount.setText(String.valueOf(newNum));

        // Goes back to inventory activity
        Intent intent = new Intent(this, InventoryActivity.class);
        // Passes user data back to inventory activity to prevent crashing that would occur
        intent.putExtra("userEmail", user.getEmail());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    // Method to delete an item
    public void deleteItem(View view) {
        // Deletes item from database
        InventoryRepository.getInstance(this).deleteItem(user.getEmail(), mItem.getItemId());
        // Goes back to inventory activity
        Intent intent = new Intent(this, InventoryActivity.class);
        // Passes user data back to inventory activity to prevent crashing that would occur
        intent.putExtra("userEmail", user.getEmail());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
