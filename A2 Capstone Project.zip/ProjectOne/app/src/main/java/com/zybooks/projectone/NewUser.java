package com.zybooks.projectone;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.zybooks.projectone.model.User;
import com.zybooks.projectone.repo.UserRepository;
import com.zybooks.projectone.viewmodel.UserListViewModel;

import java.util.List;

public class NewUser extends AppCompatActivity {
    private TextView mMatchErrorMessage;
    private TextView mDuplicateErrorMessage;
    private EditText mUserName;
    private EditText mUserEmail;
    private EditText mPassword;
    private EditText mPasswordRetype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_new_user);

        mMatchErrorMessage = findViewById(R.id.match_error_message);
        mDuplicateErrorMessage = findViewById(R.id.duplicate_error_message);
        mUserName = findViewById(R.id.userName);
        mUserEmail = findViewById(R.id.email);
        mPassword = findViewById(R.id.password);
        mPasswordRetype = findViewById(R.id.confirm_password);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Listener for mUserEmail, checks that the email is not in the system.
        mUserEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String email = mUserEmail.getText().toString();

                // Checks that there isn't a duplicate email in the system
                User user = UserRepository.getInstance(mUserEmail.getContext()).getUser(email);
                if (user != null) {
                    mDuplicateErrorMessage.setVisibility(View.VISIBLE);
                }
                else {
                    mDuplicateErrorMessage.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // Listener for mPassword, checks if not empty
        mPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = mPassword.getText().toString();

                if (password.isEmpty()) {
                    mPasswordRetype.setText("");
                    mPasswordRetype.setVisibility(View.INVISIBLE);
                }
                else {
                    mPasswordRetype.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // Listener for mPasswordRetype, checks if password is the same
        mPasswordRetype.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = mPassword.getText().toString();
                String password2 = s.toString();

                if (password.equals(password2)) {
                    mMatchErrorMessage.setVisibility(View.INVISIBLE);
                }
                else {
                    mMatchErrorMessage.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }
    public void addNewUser(View view) {
        String email = mUserEmail.getText().toString();
        String name = mUserName.getText().toString();
        String password = mPassword.getText().toString();
        String password2 = mPasswordRetype.getText().toString();
        boolean isDuplicate = false;
        boolean passwordsNotSame = false;

        // Cancel submit, if any field is empty
        if (email.isEmpty() || name.isEmpty() || password.isEmpty() || password2.isEmpty()) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        // Checks that passwords are the same
        if (!password.equals(password2)) {
            passwordsNotSame = true;
        }
        // Checks that the email is not a duplicate
        User testUser = UserRepository.getInstance(mUserEmail.getContext()).getUser(email);
        if (testUser != null) {
            isDuplicate = true;
        }

        // Cancel submit, if an error was caught
        if (passwordsNotSame || isDuplicate) {
            Toast.makeText(this, "Correct Errors In Red To Proceed", Toast.LENGTH_SHORT).show();
            return;
        }

        // Store new user in database
        User user = new User(email, name, password);
        UserRepository.getInstance(this).addUser(user);

        // Retrieve user from database, encrypt the name and phone number
        UserRepository.getInstance(this).getUser(email);
        UserRepository.getInstance(this).updateUser(email, name, user.getPassword(), user.getPhone(), user.getSalt());

        // Goes back to Login page and prompts user to login
        Toast.makeText(this, "Account Created, Please Sign In", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

}