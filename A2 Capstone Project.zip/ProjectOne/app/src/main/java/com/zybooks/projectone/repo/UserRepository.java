package com.zybooks.projectone.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import com.zybooks.projectone.model.User;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.zybooks.projectone.model.PasswordHasher;

public class UserRepository
{

    private static UserRepository userRepo;
    private final List<User> userList;
    private UserDatabase dbHelper;

    public static synchronized UserRepository getInstance(Context context)
    {
        if (userRepo == null) {
            userRepo = new UserRepository(context);
        }
        return userRepo;
    }

    private UserRepository(Context context)
    {
        userList = new ArrayList<>();
        dbHelper = new UserDatabase(context);
    }

    public List<User> getUsers()
    {
        return new ArrayList<>(userList);
    }

    // Create Method
    public void addUser(User user)
    {
        // Generates a randomly generated salt and hashes the password
        User hashedUser = PasswordHasher.hashUser(user);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        assert hashedUser != null;
        values.put(UserDatabase.UserTable.COL_EMAIL, hashedUser.getEmail());
        values.put(UserDatabase.UserTable.COL_NAME, hashedUser.getName());
        values.put(UserDatabase.UserTable.COL_PASSWORD, hashedUser.getPassword());
        values.put(UserDatabase.UserTable.COL_PHONE, hashedUser.getPhone());
        values.put(UserDatabase.UserTable.COL_SALT, hashedUser.getSalt());

        db.insert(UserDatabase.UserTable.TABLE, null, values);
        db.close();

    }

    // Read Method
    public User getUser(String email)
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        User user = null;
        Cursor cursor = null;

        try
        {
            String sql = "SELECT * FROM " + UserDatabase.UserTable.TABLE +
                    " WHERE " + UserDatabase.UserTable.COL_EMAIL + " = ? COLLATE NOCASE";
            cursor = db.rawQuery(sql, new String[]{email});

            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(UserDatabase.UserTable.COL_NAME));
                String password = cursor.getString(cursor.getColumnIndexOrThrow(UserDatabase.UserTable.COL_PASSWORD));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(UserDatabase.UserTable.COL_PHONE));
                String salt = cursor.getString(cursor.getColumnIndexOrThrow(UserDatabase.UserTable.COL_SALT));
                user = new User(email, name, password, salt, phone);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close(); // Close the database connection after use
        }

        return user;
    }

    // Update Method
    public void updateUser(String email, String name, String password, String phone, String salt)
    {
        // User encryption on name and phone before storing in database
        String orgName = PasswordHasher.computeHash(name);
        if (PasswordHasher.validateHash(name, orgName))
        {
            name = PasswordHasher.encrypt(name, password);
            if (!phone.isEmpty())
            {
                phone = PasswordHasher.encrypt(phone, password);
            }
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_EMAIL, email);
        values.put(UserDatabase.UserTable.COL_NAME, name);
        values.put(UserDatabase.UserTable.COL_PASSWORD, password);
        values.put(UserDatabase.UserTable.COL_PHONE, phone);
        values.put(UserDatabase.UserTable.COL_SALT, salt);

        db.update(UserDatabase.UserTable.TABLE, values, "email=?",
                new String[]{String.valueOf(email)});
        db.close();
    }

    // Update a user's email
    public void updateCorrectionEmail(User user, User update)
    {
        // User encryption on name and phone before storing in database
        String orgName = PasswordHasher.computeHash(user.getName());
        if (PasswordHasher.validateHash(user.getName(), orgName))
        {
            update.setName(PasswordHasher.encrypt(update.getName(), user.getPassword()));
            if (!update.getPhone().isEmpty())
            {
                update.setPhone(PasswordHasher.encrypt(update.getPhone(), user.getPassword()));
            }
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_EMAIL, update.getEmail());
        values.put(UserDatabase.UserTable.COL_NAME, update.getName());
        values.put(UserDatabase.UserTable.COL_PASSWORD, user.getPassword());
        values.put(UserDatabase.UserTable.COL_PHONE, update.getPhone());
        values.put(UserDatabase.UserTable.COL_SALT, user.getSalt());

        db.update(UserDatabase.UserTable.TABLE, values, "email=?",
                new String[]{String.valueOf(user.getEmail())});
        db.close();
    }

    // Update a user's password and salt
    public void updateCorrectionPassword(User user, User update)
    {
        // User encryption on name and phone before storing in database
        update.setName(PasswordHasher.encrypt(update.getName(), update.getPassword()));
        if (!update.getPhone().isEmpty())
        {
            update.setPhone(PasswordHasher.encrypt(update.getPhone(), update.getPassword()));
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_EMAIL, user.getEmail());
        values.put(UserDatabase.UserTable.COL_NAME, update.getName());
        values.put(UserDatabase.UserTable.COL_PASSWORD, update.getPassword());
        values.put(UserDatabase.UserTable.COL_PHONE, update.getPhone());
        values.put(UserDatabase.UserTable.COL_SALT, update.getSalt());

        db.update(UserDatabase.UserTable.TABLE, values, "email=?",
                new String[]{String.valueOf(user.getEmail())});
        db.close();
    }

    // Update all of a user's information
    public void updateCorrectionAll(User user, User update)
    {
        // User encryption on name and phone before storing in database
        update.setName(PasswordHasher.encrypt(update.getName(), update.getPassword()));
        if (!update.getPhone().isEmpty())
        {
            update.setPhone(PasswordHasher.encrypt(update.getPhone(), update.getPassword()));
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_EMAIL, update.getEmail());
        values.put(UserDatabase.UserTable.COL_NAME, update.getName());
        values.put(UserDatabase.UserTable.COL_PASSWORD, update.getPassword());
        values.put(UserDatabase.UserTable.COL_PHONE, update.getPhone());
        values.put(UserDatabase.UserTable.COL_SALT, update.getSalt());

        db.update(UserDatabase.UserTable.TABLE, values, "email=?",
                new String[]{String.valueOf(user.getEmail())});
        db.close();
    }

    // Determine which update to initiate
    public void updateCorrection(User user, User update, String whichUpdate)
    {
        // User encryption on name and phone before storing in database
        if (whichUpdate.equals("email"))
        {
            updateCorrectionEmail(user, update);
        }
        else if (whichUpdate.equals("password"))
        {
            updateCorrectionPassword(user, update);
        }
        else if (whichUpdate.equals("email and password"))
        {
            updateCorrectionAll(user, update);
        }
    }

    // Delete Method
    public void deleteUser(String email)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(UserDatabase.UserTable.TABLE, "email=?",
                new String[]{String.valueOf(email)});
        db.close();
    }
}
