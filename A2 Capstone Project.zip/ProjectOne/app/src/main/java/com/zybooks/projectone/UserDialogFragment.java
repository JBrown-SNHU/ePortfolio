package com.zybooks.projectone;

import android.content.Context;
import android.app.Dialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.zybooks.projectone.repo.UserRepository;

import java.util.concurrent.atomic.AtomicReference;

public class UserDialogFragment extends DialogFragment
{

    // Interface for passing data back to the activity
    public interface OnItemEnteredListener
    {
        void onItemEntered(String name, String phone, String email, String password);
    }

    private OnItemEnteredListener listener;

    @Override
    public void onAttach(@NonNull Context context)
    {
        super.onAttach(context);
        if (context instanceof OnItemEnteredListener)
        {
            listener = (OnItemEnteredListener) context;
        } else {
            throw new ClassCastException(context.toString() + " must implement OnItemEnteredListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        LinearLayout layout = new LinearLayout(getActivity());
        layout.setOrientation(LinearLayout.VERTICAL);

        // Create an EditText for user input
        EditText editName = new EditText(getActivity());
        EditText editPhone = new EditText(getActivity());
        EditText editEmail = new EditText(getActivity());
        EditText editPassword = new EditText(getActivity());
        EditText editPassword2 = new EditText(getActivity());

        // Set input type for password
        editPassword.setInputType(android.text.InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        editPassword2.setInputType(android.text.InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // Set hints for EditTexts
        editName.setHint("Name");
        editPhone.setHint("Phone (Optional)");
        editEmail.setHint("Email");
        editPassword.setHint("Password");
        editPassword2.setHint("Retype Password");

        Bundle args = getArguments();
        if (args != null)
        {
            editName.setText(args.getString("name", ""));
            editPhone.setText(args.getString("phone", ""));
            editEmail.setText(args.getString("email", ""));
            editPassword.setText(args.getString("password", ""));
            editPassword2.setText(args.getString("password2", ""));
        }

        // Add EditTexts to layout
        layout.addView(editName);
        layout.addView(editPhone);
        layout.addView(editEmail);
        layout.addView(editPassword);
        layout.addView(editPassword2);

        // Set bottom buttons
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle("Edit User Information")
                .setView(layout)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        AlertDialog dialog = builder.create();

        String oldEmail = editEmail.getText().toString().trim();
        dialog.setOnShowListener(d ->
        {
            Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            saveButton.setOnClickListener(view ->
            {
                Context context = getContext();
                String name = editName.getText().toString().trim();
                String email = editEmail.getText().toString().trim();
                String phone = editPhone.getText().toString().trim();
                String password = editPassword.getText().toString().trim();
                String password2 = editPassword2.getText().toString().trim();

                // Conditions for text fields
                if (name.isEmpty()) {
                    editName.setError("Name is required");
                }
                else if (email.isEmpty()) {
                    editEmail.setError("Email is required");
                }
                else if (UserRepository.getInstance(context).getUser(email) != null && !email.equals(oldEmail)) {
                    editEmail.setError("Email taken");
                }
                else if (password.isEmpty()) {
                    editPassword.setError("Password is required");
                }
                else if (password2.isEmpty()) {
                    editPassword2.setError("Retyped Password is required");
                }
                else if (!password2.equals(password)) {
                    editPassword2.setError("Passwords do not match");
                }
                else {
                    if (listener != null) {
                        listener.onItemEntered(name, phone, email, password);
                    }
                    dialog.dismiss();
                }
            });
        });

        return dialog;
    }
}