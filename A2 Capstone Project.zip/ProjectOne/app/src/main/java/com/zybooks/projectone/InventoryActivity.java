package com.zybooks.projectone;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.telephony.SmsManager;
import android.Manifest;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.model.PasswordHasher;
import com.zybooks.projectone.repo.InventoryRepository;
import com.zybooks.projectone.repo.UserRepository;
import com.zybooks.projectone.viewmodel.ItemListViewModel;
import com.zybooks.projectone.model.User;

import java.util.List;

public class InventoryActivity extends AppCompatActivity implements ItemDialogFragment.OnItemEnteredListener {

    private ItemAdapter mItemAdapter;
    private RecyclerView mRecyclerView;
    private ItemListViewModel mItemListViewModel;
    Toolbar toolbar;
    private User user;
    TextView mNoItems;
    TextView mNameField;
    TextView mAmountField;
    TextView mEditField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Sets up custom toolbar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mItemListViewModel = new ItemListViewModel(getApplication());

        findViewById(R.id.add_item_button).setOnClickListener(view -> addItemClick());

        // Create grid layout
        mRecyclerView = findViewById(R.id.item_recycler_view);
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mNameField = findViewById(R.id.items);
        mAmountField = findViewById(R.id.number);
        mEditField = findViewById(R.id.edit_field);
        mNoItems = findViewById(R.id.no_items);

        // Retrieves user data from previous screen
        Intent intent = getIntent();
        String email = intent.getStringExtra("userEmail");
        user = UserRepository.getInstance(this).getUser(email);
        if (user != null)
        {
            // Shows the items created by logged in user
            updateUI(mItemListViewModel.getItems(user.getEmail(), user.getPassword()));

            // Checks if there are any items, if not prompts user to add an item
            if (InventoryRepository.getInstance(this).getItem(user.getEmail(), 1) == null)
            {
                mNoItems.setVisibility(View.VISIBLE);
                mNameField.setVisibility(View.GONE);
                mAmountField.setVisibility(View.GONE);
                mEditField.setVisibility(View.GONE);
            }
            else
            {
                mNoItems.setVisibility(View.GONE);
                mNameField.setVisibility(View.VISIBLE);
                mAmountField.setVisibility(View.VISIBLE);
                mEditField.setVisibility(View.VISIBLE);
            }

            // Test to delete items individually
            //InventoryRepository.getInstance(this).deleteItem(user.getEmail(), 1);

            // Test to delete all items created by a user
            //InventoryRepository.getInstance(this).deleteAll(user.getEmail());
        }
        else
        {
            Toast.makeText(this, "User not found!", Toast.LENGTH_LONG).show();
            finish(); // Exit the activity to prevent further crashes
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        // Refresh the items when returning to this activity
        Intent intent = getIntent();
        String email = intent.getStringExtra("userEmail");
        user = UserRepository.getInstance(this).getUser(email);
        if (user == null)
        {
            Toast.makeText(this, "User is Null!", Toast.LENGTH_LONG).show();
        }
        updateUI(mItemListViewModel.getItems(user.getEmail(), user.getPassword()));
        if (!user.getPhone().isEmpty())
        {
            checkCountZero(mItemListViewModel);
        }

        // Checks if there are any items, if not prompts user to add an item
        if (InventoryRepository.getInstance(this).getItem(user.getEmail(), 1) == null)
        {
            mNoItems.setVisibility(View.VISIBLE);
            mNameField.setVisibility(View.GONE);
            mAmountField.setVisibility(View.GONE);
            mEditField.setVisibility(View.GONE);
        }
        else
        {
            mNoItems.setVisibility(View.GONE);
            mNameField.setVisibility(View.VISIBLE);
            mAmountField.setVisibility(View.VISIBLE);
            mEditField.setVisibility(View.VISIBLE);
        }

    }



    private void updateUI(List<Item> itemList) {
        mItemAdapter = new ItemAdapter(itemList);
        mRecyclerView.setAdapter(mItemAdapter);
    }

    // Check if an item is low or out of stock, and sends SMS message
    public void checkCountZero(ItemListViewModel list)
    {
        // Retrieves user data from previous screen
        Intent intent = getIntent();
        String email = intent.getStringExtra("userEmail");
        user = UserRepository.getInstance(this).getUser(email);
        if (user == null)
        {
            Toast.makeText(this, "User is Null!", Toast.LENGTH_LONG).show();
        }
        List<Item> itemList = list.getItems(user.getEmail(), user.getPassword());
        Context context = mRecyclerView.getContext();

        // Checks if out of stock and sends a message if so
        for (int i = 0; i < itemList.size(); ++i) {
            if (itemList.get(i).getCount() == 0) {
                Item item = itemList.get(i);
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
                } else {
                    // Replaced hardcoded password with user password
                    sendSMS(context,PasswordHasher.decrypt(user.getPhone(), user.getPassword()),
                            "Item " + item.getItemName() + " is out of stock!");
                }
            }
            // Checks if item is low and sends a message if so
            if (itemList.get(i).getCount() <= 4) {
                Item item = itemList.get(i);
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
                } else {
                    // Replaced hardcoded password with user password
                    sendSMS(context,PasswordHasher.decrypt(user.getPhone(), user.getPassword()),
                            "You are running low on " + item.getItemName() + "!");
                }
            }
        }
    }

    // Method to send SMS
    public void sendSMS(Context context, final String phoneNumber, final String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent to: " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed to Send", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        // Retrieves user data from previous screen
        Intent intent = getIntent();
        String email = intent.getStringExtra("userEmail");
        user = UserRepository.getInstance(this).getUser(email);
        if (user == null)
        {
            Toast.makeText(this, "User is Null!", Toast.LENGTH_LONG).show();
        }
        if (item.getItemId() == R.id.action_account) {
            intent = new Intent(this, UserAccountActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Pass item and user data to next screen
            intent.putExtra("userEmail", user.getEmail());
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Method to add an item to the list and database. Checks if an item already exists.
    @Override
    public void onItemEntered(String itemText, int count)
    {
        // Retrieves user data from previous screen
        Intent intent = getIntent();
        String email = intent.getStringExtra("userEmail");
        user = UserRepository.getInstance(this).getUser(email);
        if (user == null)
        {
            Toast.makeText(this, "User is Null!", Toast.LENGTH_LONG).show();
        };
        // Iterate through user list and sees if there are any duplicates
        if (!itemText.isEmpty()) {
            List<Item> myList = InventoryRepository.getInstance(this).getItems(user.getEmail(), user.getPassword());
            for (int i = 0; i < myList.size(); ++i) {
                if (myList.get(i).getItemName().equalsIgnoreCase(itemText)) {
                    Toast.makeText(this,"Item Already Exists", Toast.LENGTH_LONG).show();
                    return;
                }
            }

            // If there are no duplicates of the item, then the item is added to the list
            Item item = new Item(itemText, count, user.getEmail());
            InventoryRepository.getInstance(this).addItem(item, user.getPassword());
            updateUI(mItemListViewModel.getItems(user.getEmail(), user.getPassword()));
            onResume();
        }

        // If an item's name is empty
        else {
            Toast.makeText(this, "You Must Enter An Item Name ", Toast.LENGTH_SHORT).show();
        }
    }

    // Button to add an item
    private void addItemClick()
    {
        ItemDialogFragment dialog = new ItemDialogFragment();
        dialog.show(getSupportFragmentManager(), "itemDialog");
    }

    // Listener for recycler view buttons
    private class ItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private Item mItem;
        private final TextView mItemID;
        private final TextView mItemTextView;
        private final TextView mItemCountTextView;
        private final ImageButton mEditButton;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mItemID = itemView.findViewById(R.id.item_id_view);
            mItemTextView = itemView.findViewById(R.id.item_text_view);
            mItemCountTextView = itemView.findViewById(R.id.item_count_view);
            mEditButton = itemView.findViewById(R.id.edit_button);

            // Click lister for edit button. Takes user to Item Details Screen
            mEditButton.setOnClickListener(view-> {
                Context context = view.getContext();
                // Retrieves user data from previous screen
                Intent intent = getIntent();
                String email = intent.getStringExtra("userEmail");
                user = UserRepository.getInstance(context).getUser(email);
                if (user == null)
                {
                    Toast.makeText(context, "User is Null!", Toast.LENGTH_LONG).show();
                }

                // Encrypts in transit
                mItem.setItemName(PasswordHasher.encrypt(mItem.getItemName(), user.getPassword()));
                intent = new Intent(context, ItemDetailsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                // Pass item and user data to next screen
                intent.putExtra("item_key",mItem);
                intent.putExtra("user", user);
                context.startActivity(intent);
            });
        }

        public void bind(Item item) {
            mItem = item;
            mItemID.setText(String.valueOf(item.getItemId()));
            mItemTextView.setText(item.getItemName());
            mItemCountTextView.setText(String.valueOf(item.getCount()));
        }

        // On click method for recycler view items. I want the user to view the edit screen using
        // the edit button for the recycler view; however, the method is mandatory, so I simply
        // have it doing nothing.
        @Override
        public void onClick(View view)
        {
            // Does nothing
        }


    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItemList;

        public ItemAdapter(List<Item> items) {
            mItemList = items;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
            holder.bind(mItemList.get(position));
        }

        @Override
        public int getItemCount() {
            return mItemList.size();
        }


    }
}