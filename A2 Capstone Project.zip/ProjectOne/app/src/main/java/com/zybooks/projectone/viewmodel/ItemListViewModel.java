package com.zybooks.projectone.viewmodel;

import android.app.Application;
import com.zybooks.projectone.model.Item;
import com.zybooks.projectone.repo.InventoryRepository;
import java.util.List;

public class ItemListViewModel {

    private InventoryRepository itemRepo;

    public ItemListViewModel(Application application) {
        itemRepo = InventoryRepository.getInstance(application.getApplicationContext());
    }

    public List<Item> getItems(String createdBy, String key) {
        return itemRepo.getItems(createdBy, key);
    }

    public void addItem(Item item, String key) {
        itemRepo.addItem(item, key);
    }

}